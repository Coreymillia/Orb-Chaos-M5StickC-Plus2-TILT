/*
  M5StickCPlus2_TiltTest.ino
  Simple tilt diagnostic tool for M5StickC Plus2
  
  This program shows raw IMU values and helps calibrate tilt controls.
  Use this to understand how your device responds to tilting.

  Controls:
  - BtnA: Reset calibration
  - BtnB: Toggle display mode (raw/filtered/both)
  - Tilt device: See real-time values

  Display shows:
  - Raw accelerometer values (X, Y, Z)
  - Filtered values after processing
  - Visual ball that moves with tilt
  - Current sensitivity settings
*/

#include <M5StickCPlus2.h>

// --- Calibration and filtering settings ---
float calibAx = 0, calibAy = 0;
float filtAx = 0, filtAy = 0;
const float ACC_LP_ALPHA = 0.18f;  // Low-pass filter strength
const float ACC_DEADZONE = 0.02f;  // Minimum tilt to register
const float ACC_SENSITIVITY = 65.0f; // Sensitivity multiplier

// --- Display mode ---
enum DisplayMode { RAW_VALUES, FILTERED_VALUES, BOTH_VALUES, VISUAL_BALL };
DisplayMode displayMode = VISUAL_BALL;

// --- Test ball for visual feedback ---
float ballX = 120, ballY = 67;  // Center of screen
float velX = 0, velY = 0;
const float FRICTION = 0.985f;

unsigned long lastUpdate = 0;
bool needsCalibration = true;

void calibrateIMU() {
  StickCP2.Display.fillScreen(TFT_BLACK);
  StickCP2.Display.setCursor(10, 30);
  StickCP2.Display.setTextColor(TFT_YELLOW);
  StickCP2.Display.setTextSize(1);
  StickCP2.Display.println("Calibrating IMU...");
  StickCP2.Display.println("Keep device FLAT");
  StickCP2.Display.println("for 2 seconds");
  
  const int samples = 80;  // 2 seconds worth
  float sx = 0, sy = 0;
  
  for(int i = 0; i < samples; i++) {
    StickCP2.Imu.update();
    auto data = StickCP2.Imu.getImuData();
    sx += data.accel.x;
    sy += data.accel.y;
    delay(25);
  }
  
  calibAx = sx / samples;
  calibAy = sy / samples;
  
  StickCP2.Display.fillScreen(TFT_BLACK);
  StickCP2.Display.setCursor(10, 30);
  StickCP2.Display.setTextColor(TFT_GREEN);
  StickCP2.Display.printf("Calibration complete!\n");
  StickCP2.Display.printf("Offset X: %.3f\n", calibAx);
  StickCP2.Display.printf("Offset Y: %.3f\n", calibAy);
  delay(2000);
  needsCalibration = false;
}

void updateIMU() {
  if (StickCP2.Imu.update()) {
    auto data = StickCP2.Imu.getImuData();
    
    // Apply calibration
    float rawAx = data.accel.x - calibAx;
    float rawAy = data.accel.y - calibAy;
    
    // Apply deadzone
    if (fabs(rawAx) < ACC_DEADZONE) rawAx = 0;
    if (fabs(rawAy) < ACC_DEADZONE) rawAy = 0;
    
    // Low-pass filter
    filtAx = filtAx * (1.0 - ACC_LP_ALPHA) + rawAx * ACC_LP_ALPHA;
    filtAy = filtAy * (1.0 - ACC_LP_ALPHA) + rawAy * ACC_LP_ALPHA;
  }
}

void drawRawValues() {
  StickCP2.Display.fillScreen(TFT_BLACK);
  StickCP2.Display.setTextColor(TFT_WHITE);
  StickCP2.Display.setTextSize(1);
  StickCP2.Display.setCursor(5, 5);
  
  StickCP2.Imu.update();
  auto data = StickCP2.Imu.getImuData();
  
  StickCP2.Display.printf("=== RAW IMU VALUES ===\n\n");
  StickCP2.Display.printf("Accel X: %+.3f\n", data.accel.x);
  StickCP2.Display.printf("Accel Y: %+.3f\n", data.accel.y);
  StickCP2.Display.printf("Accel Z: %+.3f\n\n", data.accel.z);
  
  StickCP2.Display.printf("Gyro X:  %+.3f\n", data.gyro.x);
  StickCP2.Display.printf("Gyro Y:  %+.3f\n", data.gyro.y);
  StickCP2.Display.printf("Gyro Z:  %+.3f\n\n", data.gyro.z);
  
  StickCP2.Display.setTextColor(TFT_CYAN);
  StickCP2.Display.printf("A=Mode B=Calib");
}

void drawFilteredValues() {
  StickCP2.Display.fillScreen(TFT_BLACK);
  StickCP2.Display.setTextColor(TFT_WHITE);
  StickCP2.Display.setTextSize(1);
  StickCP2.Display.setCursor(5, 5);
  
  StickCP2.Display.printf("=== FILTERED VALUES ===\n\n");
  StickCP2.Display.printf("Calibration:\n");
  StickCP2.Display.printf("  Offset X: %+.3f\n", calibAx);
  StickCP2.Display.printf("  Offset Y: %+.3f\n\n", calibAy);
  
  StickCP2.Display.printf("After Processing:\n");
  StickCP2.Display.setTextColor(TFT_GREEN);
  StickCP2.Display.printf("  Filt X: %+.3f\n", filtAx);
  StickCP2.Display.printf("  Filt Y: %+.3f\n\n", filtAy);
  
  StickCP2.Display.setTextColor(TFT_YELLOW);
  StickCP2.Display.printf("Scaled for game:\n");
  StickCP2.Display.printf("  Game X: %+.1f\n", filtAx * ACC_SENSITIVITY);
  StickCP2.Display.printf("  Game Y: %+.1f\n", filtAy * ACC_SENSITIVITY);
  
  StickCP2.Display.setTextColor(TFT_CYAN);
  StickCP2.Display.setCursor(5, 120);
  StickCP2.Display.printf("A=Mode B=Calib");
}

void drawBothValues() {
  StickCP2.Display.fillScreen(TFT_BLACK);
  StickCP2.Display.setTextSize(1);
  StickCP2.Display.setCursor(5, 5);
  
  StickCP2.Imu.update();
  auto data = StickCP2.Imu.getImuData();
  
  StickCP2.Display.setTextColor(TFT_WHITE);
  StickCP2.Display.printf("RAW -> FILTERED\n\n");
  
  StickCP2.Display.setTextColor(TFT_RED);
  StickCP2.Display.printf("X: %+.3f -> ", data.accel.x);
  StickCP2.Display.setTextColor(TFT_GREEN);
  StickCP2.Display.printf("%+.3f\n", filtAx);
  
  StickCP2.Display.setTextColor(TFT_RED);
  StickCP2.Display.printf("Y: %+.3f -> ", data.accel.y);
  StickCP2.Display.setTextColor(TFT_GREEN);
  StickCP2.Display.printf("%+.3f\n\n", filtAy);
  
  StickCP2.Display.setTextColor(TFT_YELLOW);
  StickCP2.Display.printf("Game movement:\n");
  StickCP2.Display.printf("X force: %+.1f\n", filtAx * ACC_SENSITIVITY);
  StickCP2.Display.printf("Y force: %+.1f\n\n", filtAy * ACC_SENSITIVITY);
  
  StickCP2.Display.setTextColor(TFT_CYAN);
  StickCP2.Display.printf("Deadzone: %.3f\n", ACC_DEADZONE);
  StickCP2.Display.printf("Sensitivity: %.1f\n", ACC_SENSITIVITY);
  
  StickCP2.Display.setCursor(5, 120);
  StickCP2.Display.printf("A=Mode B=Calib");
}

void drawVisualBall() {
  // Clear previous ball
  StickCP2.Display.fillCircle(ballX, ballY, 8, TFT_BLACK);
  
  // Update physics
  unsigned long now = millis();
  float dt = (now - lastUpdate) / 1000.0f;
  if (dt <= 0) dt = 0.016f;
  lastUpdate = now;
  
  // Apply tilt forces
  float accelX = filtAx * ACC_SENSITIVITY;
  float accelY = -filtAy * ACC_SENSITIVITY;  // Invert Y for screen coords
  
  velX += accelX * dt;
  velY += accelY * dt;
  
  // Apply friction
  velX *= FRICTION;
  velY *= FRICTION;
  
  // Update position
  ballX += velX * dt * 60.0f;
  ballY += velY * dt * 60.0f;
  
  // Keep ball on screen
  if (ballX < 8) { ballX = 8; velX = 0; }
  if (ballX > 232) { ballX = 232; velX = 0; }
  if (ballY < 25) { ballY = 25; velY = 0; }
  if (ballY > 127) { ballY = 127; velY = 0; }
  
  // Draw new ball
  StickCP2.Display.fillCircle(ballX, ballY, 8, TFT_RED);
  
  // Draw info overlay
  StickCP2.Display.fillRect(0, 0, 240, 20, TFT_BLACK);
  StickCP2.Display.setTextColor(TFT_WHITE);
  StickCP2.Display.setTextSize(1);
  StickCP2.Display.setCursor(5, 5);
  StickCP2.Display.printf("Tilt: X=%.2f Y=%.2f", filtAx, filtAy);
  
  StickCP2.Display.fillRect(0, 120, 240, 15, TFT_BLACK);
  StickCP2.Display.setCursor(5, 122);
  StickCP2.Display.setTextColor(TFT_CYAN);
  StickCP2.Display.printf("A=Mode B=Calib Vel: %.1f,%.1f", velX, velY);
}

void handleButtons() {
  M5.update();
  
  if (M5.BtnA.wasPressed()) {
    displayMode = (DisplayMode)((displayMode + 1) % 4);
    StickCP2.Display.fillScreen(TFT_BLACK);
    if (displayMode == VISUAL_BALL) {
      ballX = 120; ballY = 67;  // Reset ball to center
      velX = velY = 0;
    }
  }
  
  if (M5.BtnB.wasPressed()) {
    needsCalibration = true;
  }
}

void setup() {
  auto cfg = M5.config();
  StickCP2.begin(cfg);
  StickCP2.Display.setRotation(3);
  StickCP2.Display.fillScreen(TFT_BLACK);
  
  StickCP2.Display.setCursor(50, 50);
  StickCP2.Display.setTextColor(TFT_WHITE);
  StickCP2.Display.setTextSize(2);
  StickCP2.Display.println("Tilt Test");
  delay(1000);
  
  lastUpdate = millis();
}

void loop() {
  handleButtons();
  
  if (needsCalibration) {
    calibrateIMU();
  }
  
  updateIMU();
  
  switch(displayMode) {
    case RAW_VALUES:
      drawRawValues();
      delay(100);
      break;
    case FILTERED_VALUES:
      drawFilteredValues();
      delay(100);
      break;
    case BOTH_VALUES:
      drawBothValues();
      delay(100);
      break;
    case VISUAL_BALL:
      drawVisualBall();
      delay(20);
      break;
  }
}