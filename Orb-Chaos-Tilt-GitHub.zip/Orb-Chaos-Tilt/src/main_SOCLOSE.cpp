#include <M5StickCPlus2.h>

#define Disp StickCP2.Display
#define SCREEN_WIDTH 135
#define SCREEN_HEIGHT 240

// Colors
#define BLACK      0x0000
#define WHITE      0xFFFF
#define RED        0xF800
#define GREEN      0x07E0
#define BLUE       0x001F
#define YELLOW     0xFFE0
#define ORANGE     0xFC00
#define PURPLE     0x8010
#define CYAN       0x07FF
#define MAGENTA    0xF81F

// Game modes
enum GameMode {
  MENU = 0,
  CLASSIC = 1,
  ELIMINATION = 2
};

// Ball structure
struct Ball {
  float x, y;
  float vx, vy;
  float radius;
  uint16_t color;
  bool active;
};

// 🔒 LOCKED TILT SETTINGS - DO NOT CHANGE 🔒
float calibAx = 0, calibAy = 0;
float filtAx = 0, filtAy = 0;
const float ACC_LP_ALPHA = 0.18f;
const float ACC_DEADZONE = 0.02f;
const float ACC_SENSITIVITY = 45.0f;
bool needsCalibration = true;
// 🔒 END LOCKED SETTINGS 🔒

// Game variables
Ball playerBall;
Ball bounceBalls[100]; // Increased to handle 60+ balls
int activeBalls = 20;
float gameTime = 0;
GameMode currentMode = MENU;
int selectedMenuItem = 0;
int ballsRemaining = 0;
int ballsPocketed = 0;
int ballsAbsorbed = 0;

// Pocket game variables
struct Pocket {
  float x, y;
  float radius;
  uint16_t color;
};
Pocket gamePocket;

// Gravity mode variables
float gravityStrength = 0;
bool gravityMode = false;
float playerMass = 10;

// Physics constants
const float FRICTION = 0.995f;
const float BOUNCE_DAMPING = 0.85f;

// Forward declarations
void showMenu();
void handleMenuInput();
void handleGameInput();
void updateGame();
void renderGame();
void initBallBuster();
void checkCollisions();
uint16_t getRandomColor();

// Forward declarations
void showMenu();
void handleMenuInput();
void handleGameInput();
void updateGame();
void renderGame();
void initBallBuster();
void checkCollisions();
uint16_t getRandomColor();

// 🔒 LOCKED TILT FUNCTIONS - DO NOT CHANGE 🔒
void calibrateIMU() {
  Disp.fillScreen(BLACK);
  Disp.setCursor(10, 100);
  Disp.setTextColor(YELLOW);
  Disp.setTextSize(1);
  Disp.println("Calibrating IMU...");
  Disp.println("Keep device FLAT");
  Disp.println("for 2 seconds");
  
  const int samples = 80;
  float sx = 0, sy = 0;
  
  for(int i = 0; i < samples; i++) {
    StickCP2.Imu.update();
    auto data = StickCP2.Imu.getImuData();
    sx += data.accel.x;
    sy += data.accel.y;
    delay(25);
  }
  
  calibAx = sx / samples;
  calibAy = sy / samples;
  needsCalibration = false;
}

void updateIMU() {
  if (StickCP2.Imu.update()) {
    auto data = StickCP2.Imu.getImuData();
    
    float rawAx = data.accel.x - calibAx;
    float rawAy = data.accel.y - calibAy;
    
    if (fabs(rawAx) < ACC_DEADZONE) rawAx = 0;
    if (fabs(rawAy) < ACC_DEADZONE) rawAy = 0;
    
    filtAx = filtAx * (1.0 - ACC_LP_ALPHA) + rawAx * ACC_LP_ALPHA;
    filtAy = filtAy * (1.0 - ACC_LP_ALPHA) + rawAy * ACC_LP_ALPHA;
  }
}
// 🔒 END LOCKED TILT FUNCTIONS 🔒

uint16_t getRandomColor() {
  uint16_t colors[] = {RED, GREEN, BLUE, YELLOW, ORANGE, PURPLE, CYAN, MAGENTA};
  return colors[random(0, 8)];
}

void setup() {
  Serial.begin(115200);
  
  auto cfg = M5.config();
  StickCP2.begin(cfg);
  
  Serial.println("🎱 Orb Chaos with Tilt Control!");
  
  Disp.setRotation(0);
  currentMode = MENU;
}

void loop() {
  M5.update();
  gameTime += 0.016f;
  
  if (needsCalibration) {
    calibrateIMU();
  }
  
  updateIMU();
  
  if (currentMode == MENU) {
    handleMenuInput();
    showMenu();
  } else {
    handleGameInput();
    updateGame();
    renderGame();
  }
  
  delay(16);
}

void showMenu() {
  Disp.fillScreen(BLACK);
  
  // Title
  Disp.setTextColor(CYAN);
  Disp.setTextSize(2);
  Disp.setCursor(40, 20);
  Disp.println("ORB");
  Disp.setCursor(25, 40);
  Disp.println("CHAOS");
  
  // Menu items
  Disp.setTextSize(1);
  
  if (selectedMenuItem == 0) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 70);
    Disp.println("> 1. CLASSIC");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 70);
    Disp.println("  1. CLASSIC");
  }
  
  if (selectedMenuItem == 1) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 85);
    Disp.println("> 2. ELIMINATION");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 85);
    Disp.println("  2. ELIMINATION");
  }
  
  if (selectedMenuItem == 2) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 100);
    Disp.println("> 3. POCKET");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 100);
    Disp.println("  3. POCKET");
  }
  
  if (selectedMenuItem == 3) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 115);
    Disp.println("> 4. SPLITTER");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 115);
    Disp.println("  4. SPLITTER");
  }
  
  if (selectedMenuItem == 4) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 130);
    Disp.println("> 5. GRAVITY");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 130);
    Disp.println("  5. GRAVITY");
  }
  
  if (selectedMenuItem == 5) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 145);
    Disp.println("> 6. RAPID FIRE");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 145);
    Disp.println("  6. RAPID FIRE");
  }
  
  if (selectedMenuItem == 6) {
    Disp.setTextColor(YELLOW);
    Disp.setCursor(20, 160);
    Disp.println("> 7. TRACERS");
  } else {
    Disp.setTextColor(WHITE);
    Disp.setCursor(20, 160);
    Disp.println("  7. TRACERS");
  }
  
  // Instructions
  Disp.setTextColor(GREEN);
  Disp.setCursor(5, 200);
  Disp.println("Tilt=Nav A=Select");
}

void handleMenuInput() {
  static unsigned long lastTiltTime = 0;
  
  if (millis() - lastTiltTime > 300) {
    if (filtAy > 0.15f && selectedMenuItem > 0) {
      selectedMenuItem--;
      lastTiltTime = millis();
    } else if (filtAy < -0.15f && selectedMenuItem < 6) { // 7 menu items (0-6)
      selectedMenuItem++;
      lastTiltTime = millis();
    }
  }
  
  if (M5.BtnA.wasClicked()) {
    if (selectedMenuItem == 0) {
      currentMode = CLASSIC;
      initBallBuster();
    } else if (selectedMenuItem == 1) {
      currentMode = ELIMINATION;
      initBallBuster();
    } else if (selectedMenuItem == 2) {
      currentMode = (GameMode)3; // POCKET
      initBallBuster();
    } else if (selectedMenuItem == 3) {
      currentMode = (GameMode)4; // SPLITTER
      initBallBuster();
    } else if (selectedMenuItem == 4) {
      currentMode = (GameMode)5; // GRAVITY
      initBallBuster();
    } else if (selectedMenuItem == 5) {
      currentMode = (GameMode)6; // RAPID_FIRE
      initBallBuster();
    } else if (selectedMenuItem == 6) {
      currentMode = (GameMode)7; // TRACERS
      initBallBuster();
    }
  }
  
  if (M5.BtnPWR.wasClicked()) {
    needsCalibration = true;
  }
}

void handleGameInput() {
  if (M5.BtnB.wasClicked()) {
    currentMode = MENU;
    return;
  }
  
  // 🔒 LOCKED TILT CONTROL - DO NOT CHANGE 🔒
  float deltaX = -filtAx * ACC_SENSITIVITY;
  float deltaY = filtAy * ACC_SENSITIVITY;
  // 🔒 END LOCKED TILT CONTROL 🔒
  
  // GRAVITY MODE: Special controls
  if (currentMode == (GameMode)5) { // GRAVITY
    // Movement is slower in gravity mode
    float moveSpeed = 0.8f;
    
    if (abs(deltaX) > 2.0f || abs(deltaY) > 2.0f) {
      playerBall.x += deltaX * moveSpeed * 0.016f * 60.0f;
      playerBall.y += deltaY * moveSpeed * 0.016f * 60.0f;
      
      playerBall.x = constrain(playerBall.x, playerBall.radius, SCREEN_WIDTH - playerBall.radius);
      playerBall.y = constrain(playerBall.y, playerBall.radius, SCREEN_HEIGHT - playerBall.radius);
    }
    
    // Button A controls gravity mode (attract/repel)
    if (M5.BtnA.isPressed()) {
      gravityStrength = 150.0f; // Strong repulsion when pressed
      gravityMode = false; // Repel
    } else {
      gravityStrength = 80.0f; // Gentle attraction when not pressed  
      gravityMode = true; // Attract
    }
  } else {
    // Normal movement for other modes
    if (abs(deltaX) > 2.0f || abs(deltaY) > 2.0f) {
      playerBall.x += deltaX * 0.016f * 60.0f;
      playerBall.y += deltaY * 0.016f * 60.0f;
      
      playerBall.x = constrain(playerBall.x, playerBall.radius, SCREEN_WIDTH - playerBall.radius);
      playerBall.y = constrain(playerBall.y, playerBall.radius, SCREEN_HEIGHT - playerBall.radius);
    }
  }
}

void initBallBuster() {
  // Initialize player ball
  playerBall.x = SCREEN_WIDTH / 2;
  playerBall.y = SCREEN_HEIGHT / 2;
  playerBall.vx = 0;
  playerBall.vy = 0;
  playerBall.radius = 6;
  playerBall.color = WHITE;
  playerBall.active = true;
  
  // Set ball count based on mode
  if (currentMode == ELIMINATION) {
    activeBalls = 80; // Reduced from 120 - more manageable
  } else if (currentMode == (GameMode)3) { // POCKET
    activeBalls = 25;
  } else if (currentMode == (GameMode)4) { // SPLITTER
    activeBalls = 3; // Start with just a few big balls
  } else if (currentMode == (GameMode)5) { // GRAVITY
    activeBalls = 20;
    playerBall.radius = 8; // Bigger for gravity well
    playerBall.color = BLACK; // Black hole appearance
  } else if (currentMode == (GameMode)6) { // RAPID_FIRE
    activeBalls = 50; // Max balls for rapid fire
  } else if (currentMode == (GameMode)7) { // TRACERS
    activeBalls = 20; // Keep tracers at 20
  } else {
    activeBalls = 60; // CLASSIC - 3x more balls!
  }
  
  ballsRemaining = activeBalls;
  ballsPocketed = 0;
  ballsAbsorbed = 0;
  
  // Initialize pocket for POCKET mode
  if (currentMode == (GameMode)3) { // POCKET
    gamePocket.x = 15;
    gamePocket.y = 15;
    gamePocket.radius = 12;
    gamePocket.color = PURPLE;
  }
  
  // Clear all balls first
  for (int i = 0; i < 100; i++) {
    bounceBalls[i].active = false;
  }
  
  // Initialize bouncing balls
  for (int i = 0; i < activeBalls; i++) {
    bounceBalls[i].x = random(20, SCREEN_WIDTH - 20);
    bounceBalls[i].y = random(20, SCREEN_HEIGHT - 20);
    
    // Set velocity based on mode
    if (currentMode == (GameMode)6) { // RAPID_FIRE
      bounceBalls[i].vx = random(-80, 80);
      bounceBalls[i].vy = random(-80, 80);
      bounceBalls[i].radius = 2; // Tiny fast balls
    } else if (currentMode == (GameMode)7) { // TRACERS
      bounceBalls[i].vx = random(-70, 70);
      bounceBalls[i].vy = random(-70, 70);
      bounceBalls[i].radius = random(3, 6);
    } else if (currentMode == (GameMode)4) { // SPLITTER
      if (i == 0) {
        bounceBalls[i].radius = 15; // One big ball
        bounceBalls[i].color = RED;
      } else {
        bounceBalls[i].radius = random(8, 12);
        bounceBalls[i].color = getRandomColor();
      }
      bounceBalls[i].vx = random(-40, 40);
      bounceBalls[i].vy = random(-40, 40);
    } else {
      bounceBalls[i].vx = random(-50, 50);
      bounceBalls[i].vy = random(-50, 50);
      bounceBalls[i].radius = random(3, 7);
    }
    
    if (currentMode != (GameMode)4) { // Not splitter mode
      bounceBalls[i].color = getRandomColor();
    }
    
    bounceBalls[i].active = true;
  }
  
  // Special setup for GRAVITY mode
  if (currentMode == (GameMode)5) { // GRAVITY
    gravityStrength = 80.0f;
    gravityMode = true; // Start in attract mode
  }
}

void updateGame() {
  ballsRemaining = 0;
  
  // Update bouncing balls
  for (int i = 0; i < 100; i++) {
    if (!bounceBalls[i].active) continue;
    
    ballsRemaining++;
    
    // Update position
    bounceBalls[i].x += bounceBalls[i].vx * 0.016f;
    bounceBalls[i].y += bounceBalls[i].vy * 0.016f;
    
    // Wall bouncing
    if (bounceBalls[i].x <= bounceBalls[i].radius || bounceBalls[i].x >= SCREEN_WIDTH - bounceBalls[i].radius) {
      bounceBalls[i].vx = -bounceBalls[i].vx * BOUNCE_DAMPING;
      bounceBalls[i].x = constrain(bounceBalls[i].x, bounceBalls[i].radius, SCREEN_WIDTH - bounceBalls[i].radius);
    }
    
    if (bounceBalls[i].y <= bounceBalls[i].radius || bounceBalls[i].y >= SCREEN_HEIGHT - bounceBalls[i].radius) {
      bounceBalls[i].vy = -bounceBalls[i].vy * BOUNCE_DAMPING;
      bounceBalls[i].y = constrain(bounceBalls[i].y, bounceBalls[i].radius, SCREEN_HEIGHT - bounceBalls[i].radius);
    }
    
    // Apply friction
    bounceBalls[i].vx *= FRICTION;
    bounceBalls[i].vy *= FRICTION;
    
    // Change color occasionally
    if (random(0, 500) == 1) {
      bounceBalls[i].color = getRandomColor();
    }
  }
  
  // Check collisions
  checkCollisions();
}

void checkCollisions() {
  // Track player ball velocity for speed-based collisions
  static float lastPlayerX = playerBall.x;
  static float lastPlayerY = playerBall.y;
  float playerSpeedX = (playerBall.x - lastPlayerX) * 60; // Convert to pixels/second
  float playerSpeedY = (playerBall.y - lastPlayerY) * 60;
  float playerSpeed = sqrt(playerSpeedX * playerSpeedX + playerSpeedY * playerSpeedY);
  
  // Player ball vs bounce balls
  for (int i = 0; i < 100; i++) {
    if (!bounceBalls[i].active) continue;
    
    float dx = playerBall.x - bounceBalls[i].x;
    float dy = playerBall.y - bounceBalls[i].y;
    float distance = sqrt(dx * dx + dy * dy);
    
    if (distance < playerBall.radius + bounceBalls[i].radius) {
      // Collision! Push based on player speed and direction
      float angle = atan2(dy, dx);
      
      // Calculate push force based on player speed
      float basePushForce = 60;
      float speedMultiplier = 1.0f + (playerSpeed * 0.02f);
      float totalPushForce = basePushForce * speedMultiplier;
      
      // Add player momentum to the collision
      float momentumTransfer = 0.3f;
      bounceBalls[i].vx = -cos(angle) * totalPushForce + playerSpeedX * momentumTransfer;
      bounceBalls[i].vy = -sin(angle) * totalPushForce + playerSpeedY * momentumTransfer;
      
      // SPLITTER MODE: Ball splits if big enough
      if (currentMode == (GameMode)4 && bounceBalls[i].radius > 3) { // SPLITTER
        // Find empty slot for new ball
        for (int j = 0; j < 100; j++) {
          if (!bounceBalls[j].active) {
            // Create split ball
            bounceBalls[j].x = bounceBalls[i].x + random(-10, 10);
            bounceBalls[j].y = bounceBalls[i].y + random(-10, 10);
            bounceBalls[j].vx = bounceBalls[i].vx + random(-30, 30);
            bounceBalls[j].vy = bounceBalls[i].vy + random(-30, 30);
            bounceBalls[j].radius = bounceBalls[i].radius - 1; // Smaller
            bounceBalls[j].color = getRandomColor();
            bounceBalls[j].active = true;
            
            // Shrink original ball
            bounceBalls[i].radius--;
            bounceBalls[i].color = getRandomColor();
            
            Serial.println("⭐ Ball " + String(i) + " split! New ball " + String(j) + " created!");
            break;
          }
        }
      } else {
        // Change color on hit (for non-splitter modes)
        bounceBalls[i].color = getRandomColor();
      }
      
      // Separate balls to prevent overlap
      float overlap = (playerBall.radius + bounceBalls[i].radius) - distance;
      bounceBalls[i].x -= cos(angle) * overlap;
      bounceBalls[i].y -= sin(angle) * overlap;
    }
  }
  
  // Ball-to-ball collisions
  for (int i = 0; i < 100; i++) {
    if (!bounceBalls[i].active) continue;
    
    for (int j = i + 1; j < 100; j++) {
      if (!bounceBalls[j].active) continue;
      
      float dx = bounceBalls[i].x - bounceBalls[j].x;
      float dy = bounceBalls[i].y - bounceBalls[j].y;
      float distance = sqrt(dx * dx + dy * dy);
      
      if (distance < bounceBalls[i].radius + bounceBalls[j].radius) {
        if (currentMode == ELIMINATION) {
          // ELIMINATION: Faster ball eliminates slower ball
          float speed_i = sqrt(bounceBalls[i].vx * bounceBalls[i].vx + bounceBalls[i].vy * bounceBalls[i].vy);
          float speed_j = sqrt(bounceBalls[j].vx * bounceBalls[j].vx + bounceBalls[j].vy * bounceBalls[j].vy);
          
          if (speed_i > speed_j) {
            bounceBalls[j].active = false;
            bounceBalls[i].color = getRandomColor();
          } else {
            bounceBalls[i].active = false;
            bounceBalls[j].color = getRandomColor();
          }
        } else {
          // CLASSIC: Exchange velocities with energy loss
          float tempVx = bounceBalls[i].vx;
          float tempVy = bounceBalls[i].vy;
          
          bounceBalls[i].vx = bounceBalls[j].vx * 0.95f;
          bounceBalls[i].vy = bounceBalls[j].vy * 0.95f;
          bounceBalls[j].vx = tempVx * 0.95f;
          bounceBalls[j].vy = tempVy * 0.95f;
          
          // Separate balls to prevent sticking
          float angle = atan2(dy, dx);
          float overlap = (bounceBalls[i].radius + bounceBalls[j].radius) - distance;
          bounceBalls[i].x += cos(angle) * overlap * 0.5f;
          bounceBalls[i].y += sin(angle) * overlap * 0.5f;
          bounceBalls[j].x -= cos(angle) * overlap * 0.5f;
          bounceBalls[j].y -= sin(angle) * overlap * 0.5f;
        }
      }
    }
  }
  
  // Update last player position for next frame
  lastPlayerX = playerBall.x;
  lastPlayerY = playerBall.y;
}

void renderGame() {
  // Handle tracers mode differently
  if (currentMode == (GameMode)7) { // TRACERS
    // Create tracer effect - don't clear completely
    for (int y = 0; y < SCREEN_HEIGHT; y += 2) {
      for (int x = 0; x < SCREEN_WIDTH; x += 2) {
        Disp.drawPixel(x, y, 0x1082); // Fade every other pixel
      }
    }
  } else {
    Disp.fillScreen(BLACK);
  }
  
  // Draw pocket for POCKET mode
  if (currentMode == (GameMode)3) { // POCKET
    Disp.fillCircle(gamePocket.x, gamePocket.y, gamePocket.radius, gamePocket.color);
    Disp.drawCircle(gamePocket.x, gamePocket.y, gamePocket.radius, WHITE);
    // Add swirl effect
    Disp.drawCircle(gamePocket.x, gamePocket.y, gamePocket.radius - 3, BLACK);
  }
  
  // Draw bouncing balls
  for (int i = 0; i < 100; i++) {
    if (bounceBalls[i].active) {
      Disp.fillCircle(bounceBalls[i].x, bounceBalls[i].y, bounceBalls[i].radius, bounceBalls[i].color);
      // Add shine effect
      Disp.drawPixel(bounceBalls[i].x - 1, bounceBalls[i].y - 1, WHITE);
      
      // Special outline for big balls in splitter mode
      if (currentMode == (GameMode)4 && bounceBalls[i].radius > 10) { // SPLITTER
        Disp.drawCircle(bounceBalls[i].x, bounceBalls[i].y, bounceBalls[i].radius + 1, WHITE);
      }
    }
  }
  
  // Draw player ball with special effects for gravity mode
  if (currentMode == (GameMode)5) { // GRAVITY
    // Draw gravity well effect
    for (int r = playerBall.radius + 3; r <= playerBall.radius + 12; r += 3) {
      uint16_t color = gravityMode ? BLUE : RED; // Blue attract, Red repel
      Disp.drawCircle(playerBall.x, playerBall.y, r, color);
    }
    
    // Draw black hole center
    Disp.fillCircle(playerBall.x, playerBall.y, playerBall.radius, BLACK);
    Disp.drawCircle(playerBall.x, playerBall.y, playerBall.radius + 1, WHITE);
  } else {
    // Normal player ball
    Disp.fillCircle(playerBall.x, playerBall.y, playerBall.radius, playerBall.color);
    Disp.drawCircle(playerBall.x, playerBall.y, playerBall.radius + 1, CYAN);
  }
  
  // UI based on mode - CLEAN GAMEPLAY (no text except Tracers)
  if (currentMode == (GameMode)7) { // TRACERS - keep text
    Disp.setTextColor(WHITE);
    Disp.setTextSize(1);
    Disp.setCursor(5, 5);
    Disp.print("Balls: ");
    Disp.println(ballsRemaining);
    Disp.setCursor(70, 5);
    Disp.println("TRACERS");
  }
  // All other modes: NO TEXT for clean gameplay!
  
  // Show win messages when needed
  if (currentMode == ELIMINATION && ballsRemaining <= 1) {
    Disp.setTextColor(YELLOW);
    Disp.setTextSize(2);
    Disp.setCursor(20, 120);
    Disp.println("YOU WIN!");
  } else if (currentMode == (GameMode)3 && ballsRemaining <= 0) { // POCKET
    Disp.setTextColor(YELLOW);
    Disp.setTextSize(2);
    Disp.setCursor(25, 120);
    Disp.println("ALL IN!");
  } else if (currentMode == (GameMode)4) { // SPLITTER
    // Check if all balls are tiny
    bool allTiny = true;
    for (int i = 0; i < 100; i++) {
      if (bounceBalls[i].active && bounceBalls[i].radius > 2) {
        allTiny = false;
        break;
      }
    }
    
    if (allTiny && ballsRemaining > 0) {
      Disp.setTextColor(YELLOW);
      Disp.setTextSize(2);
      Disp.setCursor(30, 120);
      Disp.println("SPLIT!");
    }
  } else if (currentMode == (GameMode)5 && ballsRemaining <= 0) { // GRAVITY
    Disp.setTextColor(YELLOW);
    Disp.setTextSize(2);
    Disp.setCursor(15, 120);
    Disp.println("ABSORBED!");
  }
  
  // Exit instruction
  Disp.setTextColor(CYAN);
  Disp.setCursor(85, SCREEN_HEIGHT - 15);
  Disp.println("B=Menu");
}