# 🚀 **M5STICKC PLUS2 MASTER TEMPLATE**
## Universal Starting Point for All M5StickC Plus2 Projects

---

## 🎯 **WHAT THIS IS**

This is your **complete, battle-tested foundation** for any M5StickC Plus2 project. Everything is pre-configured and proven to work, based on the successful biorhythm calculator project.

---

## 📋 **HOW TO USE THIS TEMPLATE**

### **Step 1: Copy Template for New Project**
```bash
# Copy the entire template folder
cp -r /home/coreymillia/Documents/M5StickC-Plus2-Master-Template /home/coreymillia/Documents/Your-New-Project-Name

cd /home/coreymillia/Documents/Your-New-Project-Name
```

### **Step 2: Customize Your Project**
1. **Edit `src/main.cpp`**:
   - Change app name in `drawWelcomeScreen()`
   - Add your app-specific states to the `AppState` enum
   - Customize menu items in `drawMainMenu()`
   - Add your app logic to the state handlers

2. **Edit `create_m5burner_package.sh`**:
   - Change `PROJECT_NAME="YourProjectName"`
   - Change `DESCRIPTION="Your project description"`
   - Change `CATEGORY="Applications"` (if needed)

3. **Edit `platformio.ini`** (if needed):
   - Add additional libraries to `lib_deps`

### **Step 3: Develop Your App**
```bash
# Build and test during development
pio run --target upload

# Monitor serial output for debugging
pio device monitor --port /dev/ttyACM0 --baud 115200
```

### **Step 4: Create M5Burner Package**
```bash
# When ready for distribution
./create_m5burner_package.sh
```

**That's it! Ready for M5Burner upload!** 🎉

---

## 📱 **WHAT'S INCLUDED & PRE-CONFIGURED**

### ✅ **Perfect Display Setup**
- Portrait mode (135x240) optimized
- Proven color schemes for maximum visibility
- Text drawing utilities
- Animation framework ready

### ✅ **Reliable Button System**
- Debounced button handling with `wasClicked()`
- Power management configured to prevent issues
- Hold-button detection for advanced controls

### ✅ **Data Persistence Ready**
- Preferences system pre-configured
- Save/load functions template included
- Settings menu framework ready

### ✅ **M5Burner Success Guaranteed**
- Automated merged binary creation
- Proper flash layout (bootloader + partitions + app)
- Complete M5Burner configuration template
- One-command packaging script

### ✅ **Production-Ready Framework**
- State machine for clean app organization
- Menu system template
- Battery monitoring
- Error handling
- Professional UI patterns

---

## 🎨 **PROVEN COLOR PALETTE**

```cpp
#define GREEN_SELECT    0x07E0  // Bright green for selection
#define CYAN_BLUE       0x07FF  // Perfect for readable text  
#define WHITE_TEXT      WHITE   // Standard white
#define YELLOW_BRIGHT   0xFFE0  // Bright yellow
#define RED_CYCLE       0xF800  // Red for alerts/warnings
#define ORANGE_MID      0xFC00  // Orange for mid-range values
#define GRAY_SUBTLE     0x8410  // Subtle gray for lines
#define PURPLE_DARK     0x8010  // Dark purple accent
```

**These colors are tested and proven for maximum visibility on the M5StickC Plus2 screen!**

---

## 🎮 **STANDARD BUTTON LAYOUT**

- **M5 Button**: Primary action (select, confirm, next)
- **B Button**: Secondary action (back, cancel, previous)  
- **PWR Button**: Settings, options, or field switching

**This pattern is consistent and intuitive for users!**

---

## 📦 **PROJECT STRUCTURE**

```
Your-New-Project/
├── src/
│   └── main.cpp                 // Complete app template
├── include/                     // Header files
├── lib/                         // Custom libraries  
├── test/                        // Unit tests
├── releases/                    // Generated packages
│   └── v1.0/
│       ├── M5Burner_Package/    // Ready for upload
│       └── source_backup/       // Source code backup
├── platformio.ini               // Optimized configuration
├── create_m5burner_package.sh   // One-command packaging
└── README.md                    // This documentation
```

---

## 🚀 **KEY SUCCESS FACTORS**

### **Display System**
- Always use portrait mode (`Disp.setRotation(0)`)
- Use proven color codes for visibility
- Layout: Title (y=10-40), Content (y=50-180), Controls (y=190-240)

### **Button Handling**  
- Always call `M5.update()` first in loop
- Use `wasClicked()` for reliable single-press detection
- Include 50ms delay in main loop

### **M5Burner Compatibility**
- Always create merged binary (bootloader + partitions + app)
- Flash offset must be 0x0 for M5Burner
- Test merged binary before distributing

### **Performance**
- Keep main loop efficient
- Use state machine for clean organization
- Optimize graphics for 135x240 resolution

---

## 💡 **CUSTOMIZATION EXAMPLES**

### **Adding New States**
```cpp
enum AppState {
  WELCOME_SCREEN,
  MAIN_MENU,
  YOUR_NEW_STATE,    // Add here
  SETTINGS_MENU,
  INFO_SCREEN
};

// Add to switch statement in loop()
case YOUR_NEW_STATE:
  handleYourNewState();
  break;
```

### **Adding Visual Effects**
```cpp
// Use the included rainbow color function
uint16_t color = getRainbowColor(0.5); // 0.0 to 1.0

// Animated pixels  
drawAnimatedPixel(x, y, millis(), 2.0); // speed = 2.0
```

### **Adding Settings**
```cpp
// In saveSettings()
preferences.putInt("yourSetting", value);

// In loadSettings()  
yourValue = preferences.getInt("yourSetting", defaultValue);
```

---

## 🎯 **READY FOR ANY PROJECT TYPE**

This template works perfectly for:
- 🎮 **Games** (Tetris, puzzles, arcade)
- 🎨 **Visual Apps** (screensavers, art, animations)  
- 🔧 **Utilities** (calculators, tools, monitors)
- 📊 **Data Apps** (sensors, logging, display)
- 🎵 **Entertainment** (music, effects, demos)

---

## ✨ **GUARANTEED SUCCESS**

**This template eliminates all the trial-and-error!**

✅ No display issues  
✅ No button problems  
✅ No M5Burner corruption  
✅ No flash failures  
✅ No color visibility problems  
✅ No state management confusion  

**Everything is tested, proven, and ready to go!**

---

## 🎊 **START YOUR NEXT AMAZING PROJECT NOW!**

Just copy this template, customize it for your idea, and you'll have a professional M5StickC Plus2 app ready for M5Burner distribution in minutes, not hours!

**Your path to M5StickC Plus2 mastery starts here!** 🚀