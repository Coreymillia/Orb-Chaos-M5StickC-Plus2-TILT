🎮 ORB CHAOS - TILT CONTROL 🎮
===============================

📅 Version: 1.0.0 FINAL
🎯 Device: M5StickCPlus2 ONLY
💾 File Size: 435KB
🚫 External Hardware: NONE REQUIRED

🎉 COMPLETE 7-GAME PHYSICS PLAYGROUND!
======================================

✅ WHAT'S INCLUDED:
- ✅ Perfect tilt control (no Joy-C hat needed!)
- ✅ 7 unique physics-based games
- ✅ Clean minimalist interface
- ✅ Smooth 60 FPS performance
- ✅ Instant play - just flash and go!

🎯 7 GAME MODES:
================
1. 🌀 CLASSIC - 60 bouncing balls with realistic physics
2. ⚔️  ELIMINATION - 80 balls battle until one remains
3. 🕳️  POCKET - Sink 25 balls into the purple pocket
4. 💥 SPLITTER - Hit balls to split them into pieces
5. 🌑 GRAVITY - Your orb becomes a gravity well/black hole
6. 🔥 RAPID FIRE - 50 tiny super-fast balls
7. ✨ TRACERS - Balls leave beautiful light trails

🎮 CONTROLS:
============
📱 Tilt Device → Move your white orb
🔘 Button A → Select menu / Toggle gravity mode
🔘 Button B → Return to menu (in games)
🔋 Power Button → Recalibrate tilt sensor

🚀 INSTALLATION:
================
1. Open M5Burner
2. Connect your M5StickCPlus2
3. Flash "Orb-Chaos-Tilt-FINAL.bin"
4. Play immediately!

📋 FIRST RUN:
=============
- Device will calibrate tilt sensor automatically
- Keep device FLAT during 2-second calibration
- Use tilt navigation in menu
- Press Button A to select games

🎯 GAMEPLAY TIPS:
=================
- Move fast for harder ball impacts
- Each game has unique physics
- Clean interface = pure gameplay focus
- Gravity mode: Hold Button A to repel
- Experiment with different tilt angles

⚠️  DEVICE COMPATIBILITY:
=========================
✅ M5StickCPlus2 - PERFECT
❌ M5StickC - NOT COMPATIBLE
❌ M5Stack - NOT COMPATIBLE
❌ Other M5 devices - NOT TESTED

🔧 TECHNICAL INFO:
==================
- Flash Size: 445KB
- RAM Usage: 8.4%
- Frame Rate: 60 FPS
- Physics Engine: Custom built
- No WiFi/Bluetooth used
- Battery optimized

🎉 ENJOY THE CHAOS! 🎉
======================