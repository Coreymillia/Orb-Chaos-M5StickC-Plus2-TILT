# 🌌 Orb Chaos Tilt - Motion-Controlled Gaming for M5StickC Plus2

## 🎮 **Revolutionary Tilt Control Gaming**

Advanced **motion-controlled** version of Orb Chaos featuring **7 game modes** controlled entirely by **tilting your M5StickC Plus2** device!

## ✨ **7 Tilt-Controlled Game Modes**

### **Mode 1: Classic** 🔵
- Tilt to control paddle and ball interactions
- Natural motion physics with device orientation
- Intuitive gameplay using built-in IMU

### **Mode 2: Elimination** ⚡
- Tilt-based ball elimination mechanics
- Strategic device positioning for survival
- Motion-controlled collision avoidance

### **Mode 3: Pocket** 🕳️
- Precision tilt control to guide balls into holes
- Fine motor control challenges
- Device angle determines ball trajectory

### **Mode 4: Splitter** ✂️
- Tilt to create and control ball splitting
- Complex multi-ball tilt management
- Chaos controlled by device motion

### **Mode 5: Gravity Well** 🌌
- Device tilt creates gravitational effects
- Physics-based orbital control via motion
- Revolutionary motion-to-gravity mechanics

### **Mode 6: Rapid Fire** 🔥
- High-speed tilt response for 50 balls
- Fast reflex tilt gaming
- Motion-controlled mayhem

### **Mode 7: Tracers** 🌈
- Tilt with visual ball trails
- Enhanced motion feedback
- Beautiful physics visualization

## 🎯 **Revolutionary Motion Controls**

### **Built-in IMU Sensors:**
- **Tilt Up/Down**: Primary game control
- **Tilt Left/Right**: Secondary mechanics
- **Device Rotation**: Advanced physics control
- **Button A**: Cycle game modes
- **Auto-Calibration**: Intelligent motion sensing

## 🔧 **Hardware Requirements**

- **M5StickC Plus2** (built-in IMU required)
- **No external hardware needed!**
- **Motion sensors**: 6-axis IMU integration

## 🚀 **Installation**

### **Option 1: M5Burner (Easiest)**
1. Use M5Burner app
2. Flash the included `.bin` file
3. Hold device and start tilting!

### **Option 2: Build from Source**
```bash
# Requires PlatformIO
pio run --target upload
```

## 🎨 **Motion Gaming Features**

- ✅ **Pure motion control** - no external hardware needed
- ✅ **7 unique tilt-based** game modes
- ✅ **Advanced IMU integration** with calibration
- ✅ **Responsive motion physics** engine
- ✅ **Natural device interaction** 
- ✅ **Smooth tilt response** with filtering
- ✅ **Visual motion feedback** system

## 🏆 **Technical Innovation**

- **Motion Engine**: Advanced IMU processing with deadzone and sensitivity tuning
- **Physics**: Device orientation directly controls game physics
- **Calibration**: Automatic motion baseline detection
- **Filtering**: Low-pass filtering for smooth tilt response
- **Performance**: Optimized for real-time motion processing

## 🌟 **What Makes This Special**

**World's first comprehensive tilt-controlled multi-game suite for M5StickC Plus2!**

- **No joystick needed** - pure device motion
- **Natural interaction** - tilt feels intuitive
- **Advanced physics** - motion directly affects game world
- **Multiple game types** - variety in motion mechanics

## 📱 **Perfect For**

- Motion gaming enthusiasts
- IMU sensor demonstrations
- Natural interface showcases
- Portable tilt gaming
- Physics education with motion

---

**Created by coreymillia + GitHub Copilot CLI - The future of embedded motion gaming! 🎮**